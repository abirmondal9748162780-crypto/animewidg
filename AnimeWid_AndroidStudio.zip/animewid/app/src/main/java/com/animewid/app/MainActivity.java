package com.animewid.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;
import android.os.AsyncTask;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    private static final int OVERLAY_PERMISSION_REQ = 1234;
    private LinearLayout videoListLayout;
    private EditText urlInput;
    private SharedPreferences prefs;
    private List<String[]> videoList = new ArrayList<>(); // [title, url]

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("animewid_prefs", MODE_PRIVATE);
        videoListLayout = findViewById(R.id.videoListLayout);
        urlInput = findViewById(R.id.urlInput);

        loadVideos();
        renderList();

        // Add button
        findViewById(R.id.btnAdd).setOnClickListener(v -> addVideo());

        // Check overlay permission on start
        checkOverlayPermission();
    }

    private void checkOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, OVERLAY_PERMISSION_REQ);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_PERMISSION_REQ) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Overlay permission দাও — floating video চালাতে লাগবে!", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void addVideo() {
        String url = urlInput.getText().toString().trim();
        if (url.isEmpty()) {
            Toast.makeText(this, "Video URL দাও!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Auto-generate title from URL
        String title = "Video " + (videoList.size() + 1);
        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost();
            if (host != null) {
                if (host.contains("youtube")) title = "YouTube #" + (videoList.size() + 1);
                else if (host.contains("drive.google")) title = "Drive Video #" + (videoList.size() + 1);
                else title = host + " #" + (videoList.size() + 1);
            }
        } catch (Exception ignored) {}

        videoList.add(new String[]{title, url});
        saveVideos();
        renderList();
        urlInput.setText("");
        Toast.makeText(this, "✅ সেভ হয়েছে!", Toast.LENGTH_SHORT).show();
    }

    private void renderList() {
        videoListLayout.removeAllViews();

        if (videoList.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("কোনো ভিডিও নেই। উপরে URL দিয়ে যোগ করো।");
            empty.setTextColor(Color.parseColor("#888888"));
            empty.setTextSize(13);
            empty.setPadding(0, 20, 0, 20);
            empty.setGravity(Gravity.CENTER);
            videoListLayout.addView(empty);
            return;
        }

        for (int i = 0; i < videoList.size(); i++) {
            final int index = i;
            final String[] video = videoList.get(i);

            // Row layout
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(12, 10, 12, 10);
            row.setBackgroundColor(Color.parseColor("#1a1a2e"));

            // Margins
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            rowParams.setMargins(0, 0, 0, 6);
            row.setLayoutParams(rowParams);
            row.setBackgroundResource(R.drawable.bg_row);

            // Title
            TextView title = new TextView(this);
            title.setText(video[0]);
            title.setTextColor(Color.WHITE);
            title.setTextSize(14);
            LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            title.setLayoutParams(titleParams);
            title.setMaxLines(1);
            title.setEllipsize(android.text.TextUtils.TruncateAt.END);

            // Run button
            Button runBtn = new Button(this);
            runBtn.setText("▶ Run");
            runBtn.setTextSize(12);
            runBtn.setTextColor(Color.WHITE);
            runBtn.setBackgroundResource(R.drawable.bg_btn_green);
            runBtn.setPadding(20, 8, 20, 8);
            LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            btnParams.setMargins(8, 0, 8, 0);
            runBtn.setLayoutParams(btnParams);
            runBtn.setOnClickListener(v -> runVideo(video[1]));

            // Delete button
            Button delBtn = new Button(this);
            delBtn.setText("🗑");
            delBtn.setTextSize(14);
            delBtn.setBackgroundResource(R.drawable.bg_btn_red);
            delBtn.setPadding(16, 8, 16, 8);
            delBtn.setOnClickListener(v -> {
                videoList.remove(index);
                saveVideos();
                renderList();
            });

            row.addView(title);
            row.addView(runBtn);
            row.addView(delBtn);
            videoListLayout.addView(row);
        }
    }

    private void runVideo(String url) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "আগে overlay permission দাও!", Toast.LENGTH_SHORT).show();
            checkOverlayPermission();
            return;
        }
        // Start floating video service
        Intent intent = new Intent(this, FloatingVideoService.class);
        intent.putExtra("VIDEO_URL", url);
        startForegroundService(intent);
        // Minimize app to show floating window on home screen
        moveTaskToBack(true);
    }

    private void saveVideos() {
        try {
            JSONArray arr = new JSONArray();
            for (String[] v : videoList) {
                JSONObject obj = new JSONObject();
                obj.put("title", v[0]);
                obj.put("url", v[1]);
                arr.put(obj);
            }
            prefs.edit().putString("videos", arr.toString()).apply();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void loadVideos() {
        videoList.clear();
        String json = prefs.getString("videos", "[]");
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                videoList.add(new String[]{obj.getString("title"), obj.getString("url")});
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
