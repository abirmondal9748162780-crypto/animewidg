package com.animewid.app;

import android.app.*;
import android.content.Intent;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.view.animation.DecelerateInterpolator;
import android.widget.*;
import androidx.core.app.NotificationCompat;
import android.os.IBinder;
import android.content.Context;

public class FloatingVideoService extends Service {

    private static final String CHANNEL_ID = "animewid_float";
    private WindowManager windowManager;
    private View floatingView;
    private VideoView videoView;
    private WindowManager.LayoutParams params;
    private String videoUrl;

    // Touch drag variables
    private float initialTouchX, initialTouchY;
    private int initialX, initialY;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            videoUrl = intent.getStringExtra("VIDEO_URL");
        }
        createFloatingWindow();
        startForegroundNotification();
        return START_STICKY;
    }

    private void createFloatingWindow() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        // Root container
        floatingView = new FrameLayout(this);
        FrameLayout root = (FrameLayout) floatingView;

        // Size: 320x200 dp
        int w = dpToPx(300);
        int h = dpToPx(188);

        // VideoView for playback
        videoView = new VideoView(this);
        FrameLayout.LayoutParams vpParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT);
        videoView.setLayoutParams(vpParams);
        videoView.setBackgroundColor(Color.BLACK);
        root.addView(videoView);

        // Dark gradient overlay at top (for close button visibility)
        View topGrad = new View(this);
        topGrad.setBackground(new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xCC000000, 0x00000000}));
        FrameLayout.LayoutParams gradParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dpToPx(40));
        topGrad.setLayoutParams(gradParams);
        root.addView(topGrad);

        // Close button (top-right X)
        TextView closeBtn = new TextView(this);
        closeBtn.setText("✕");
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setTextSize(16);
        closeBtn.setTypeface(null, Typeface.BOLD);
        closeBtn.setPadding(dpToPx(8), dpToPx(6), dpToPx(8), dpToPx(6));
        FrameLayout.LayoutParams closeParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        closeParams.gravity = Gravity.TOP | Gravity.END;
        closeParams.setMargins(0, dpToPx(4), dpToPx(4), 0);
        closeBtn.setLayoutParams(closeParams);
        closeBtn.setOnClickListener(v -> stopSelf());
        root.addView(closeBtn);

        // Rounded corners clip
        root.setClipToOutline(true);
        root.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dpToPx(14));
            }
        });

        // Window params
        int layoutFlag;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            layoutFlag = WindowManager.LayoutParams.TYPE_PHONE;
        }

        params = new WindowManager.LayoutParams(
                w, h,
                layoutFlag,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dpToPx(30);
        params.y = dpToPx(120);

        // Drag to move
        root.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initialX = params.x;
                    initialY = params.y;
                    initialTouchX = event.getRawX();
                    initialTouchY = event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    params.x = initialX + (int)(event.getRawX() - initialTouchX);
                    params.y = initialY + (int)(event.getRawY() - initialTouchY);
                    windowManager.updateViewLayout(floatingView, params);
                    return true;
            }
            return false;
        });

        windowManager.addView(floatingView, params);

        // Start video
        playVideo();
    }

    private void playVideo() {
        if (videoUrl == null || videoUrl.isEmpty()) return;

        Uri uri = Uri.parse(videoUrl);
        videoView.setVideoURI(uri);

        // Loop forever
        videoView.setOnPreparedListener(mp -> {
            mp.setLooping(true);
            mp.setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);
            mp.start();
        });

        videoView.setOnErrorListener((mp, what, extra) -> {
            // Try as direct URL with MediaPlayer
            Toast.makeText(this, "Video load হচ্ছে...", Toast.LENGTH_SHORT).show();
            return false;
        });

        videoView.start();
    }

    private void startForegroundNotification() {
        // Create notification channel (Android 8+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "AnimeWid Float",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Floating video player");
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }

        // Tap notification to reopen app
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        // Stop action
        Intent stopIntent = new Intent(this, FloatingVideoService.class);
        stopIntent.setAction("STOP");
        PendingIntent stopPending = PendingIntent.getService(
                this, 1, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("AnimeWid চলছে 🎬")
                .setContentText("Floating video active — টেনে সরাও")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(pendingIntent)
                .addAction(android.R.drawable.ic_delete, "বন্ধ করো", stopPending)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .build();

        startForeground(1, notification);
    }

    @Override
    public void onStartCommand(Intent intent, int flags, int startId) {
        // Handle STOP action from notification
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null) {
            videoUrl = intent.getStringExtra("VIDEO_URL");
        }
        createFloatingWindow();
        startForegroundNotification();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatingView != null) {
            try {
                if (videoView != null) videoView.stopPlayback();
                windowManager.removeView(floatingView);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}
