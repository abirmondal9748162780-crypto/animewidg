# AnimeWid — Floating Video App

## Android Studio তে কীভাবে খুলবে ও APK বানাবে

### ধাপ ১ — Android Studio ডাউনলোড করো
https://developer.android.com/studio

### ধাপ ২ — Project খোলো
1. Android Studio চালু করো
2. "Open" বা "Open an Existing Project" চাপো
3. এই `animewid` folder টা select করো
4. "OK" চাপো

### ধাপ ৩ — Sync করো
- উপরে একটা bar আসবে "Sync Now" — সেটায় চাপো
- কিছুক্ষণ অপেক্ষা করো (internet লাগবে, libraries download হবে)

### ধাপ ৪ — APK বানাও
1. উপরের menu তে যাও: **Build → Build Bundle(s)/APK(s) → Build APK(s)**
2. কিছুক্ষণ পর "Build Successful" আসবে
3. "locate" চাপলে APK file পাবে
4. APK file phone এ পাঠাও ও install করো

---

## Phone এ কীভাবে ব্যবহার করবে

1. App খোলো
2. **Overlay permission** চাইলে — দিয়ে দাও (Settings → Special App Access → Display over other apps → AnimeWid ON)
3. Video URL দাও (direct mp4 link / Google Drive share link)
4. **▶ Run** চাপো
5. App minimize হয়ে যাবে — floating video চালু হবে home screen এর উপরে!
6. Video টেনে যেকোনো জায়গায় নিয়ে যাও
7. **✕** চাপলে বন্ধ হবে

---

## কোন ধরনের URL কাজ করে

✅ Direct MP4 link — https://example.com/video.mp4
✅ Google Drive — share link (view করার link)
✅ GitHub raw video link
✅ যেকোনো direct video stream URL

❌ YouTube link সরাসরি কাজ করবে না (YouTube block করে)

---

## FloatingVideoService.java — মূল logic
- SYSTEM_ALERT_WINDOW permission দিয়ে WindowManager এ video চালায়
- MediaPlayer looping=true করা আছে
- Drag করে সরানো যায়
- Foreground service তাই background এ চলতে থাকে
